# Framework Bug Report

## Issue 1
- Title:
- Severity:
- Evidence (logs/summary):
- Steps to reproduce:
- Expected:
- Actual:
- Suspected cause:
- Proposed fix:

## Issue 2
- Title:
- Severity:
- Evidence (logs/summary):
- Steps to reproduce:
- Expected:
- Actual:
- Suspected cause:
- Proposed fix:
