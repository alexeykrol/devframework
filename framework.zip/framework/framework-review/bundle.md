# Framework Review Bundle

## Target run
- Run ID:
- Phase:
- Framework version:
- Started:
- Finished:

## Quick links
- `framework/docs/orchestrator-run-summary.md`
- `framework/logs/framework-run.jsonl`
- `framework/logs/` (task logs)
- `framework/orchestrator/orchestrator.py`
- `framework/orchestrator/orchestrator.json`

## Commands
- Main run command:
  - 
- Post-run command:
  - `python3 framework/orchestrator/orchestrator.py --phase post`

## Focus areas
- 

## Notes
- 
