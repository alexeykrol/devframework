# Task: Legacy Reverse Tech Spec (read-only)

## Goal
Сформировать обратное ТЗ из существующего кода.

## Inputs
- `framework/migration/legacy-snapshot.md`

## Outputs
- `framework/migration/legacy-tech-spec.md`

## Rules
- Не менять код.
- Опираться только на реальные факты из репозитория.

## Done When
- Tech‑spec заполнен.
