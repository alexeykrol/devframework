# Task: Legacy Gap + Risk (read-only)

## Goal
Сравнить legacy с фреймворком и выявить пробелы/риски.

## Inputs
- `framework/migration/legacy-tech-spec.md`
- `framework/docs/orchestrator-plan-ru.md`

## Outputs
- `framework/migration/legacy-gap-report.md`
- `framework/migration/legacy-risk-assessment.md`

## Rules
- Не менять код.

## Done When
- Gap и Risk заполнены.
