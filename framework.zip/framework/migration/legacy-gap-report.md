# Legacy Gap Report

## Чего не хватает относительно фреймворка
- 

## Качество процесса
- DoD:
- Review:
- Tests:
- Observability:

## Риски при миграции
- 
