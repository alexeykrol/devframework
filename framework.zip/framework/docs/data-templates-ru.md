# Шаблоны данных (stub)

Ожидаемые CSV/данные для расчётов:

- `plans_2026.csv`: `plan_id,name,metal,monthly_premium,rating_area,state`.
- `zip_rating_map_2026.csv`: `zip,rating_area,state`.
- `fpl_2026.csv`: `household_size,fpl_monthly,fpl_annual`.
- `slcsp_2026.csv`: `zip,slcsp_premium`.

Добавьте реальные или sample файлы в `framework/data/`.
