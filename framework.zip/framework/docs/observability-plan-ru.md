# Observability Plan

## Что логируем
- Ошибки API и фронтенда
- Воронка: шаги анкеты, конверсия, оплаты
- Ошибки LLM/таймауты

## Метрики
- Time to report
- Conversion (guest → auth → paid)
- Retention

## Алерты
- Сбой генерации отчёта
- Ошибка платежей

