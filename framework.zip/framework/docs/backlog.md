# Backlog (self-host devframework)

Основано на `docs/tech-spec-generated.md`, `docs/plan-generated.md` и интервью.

## P0 / MVP (обязательно для первого стабильного цикла)
1) BKL-001 — Раздельные summary по фазам (main/post/legacy) — DONE
   - Цель: не перезаписывать `orchestrator-run-summary.md`.
   - Критерии: summary сохраняется в `framework/docs/orchestrator-run-summary-<phase>-<run_id>.md`
     + ссылку на последний run писать в `orchestrator-run-summary.md`.
2) BKL-002 — Авто‑генерация артефактов из interview — DONE
   - Артефакты: `tech-spec-generated.md`, `plan-generated.md`,
     `data-inputs-generated.md`, `review/test-plan.md`.
   - Критерии: один запуск задачи генерирует полный набор без ручной правки;
     UNKNOWN/TODO фиксируются явно.
3) BKL-003 — Критерий «достаточно вопросов» в discovery — DONE
   - Критерии: фиксированный список обязательных секций + порог полноты; при
     достижении — финальное подтверждение и переход к генерации.
4) BKL-004 — Стандартизированный сбор баг‑репортов от хост‑проектов — DONE
   - Критерии: единый шаблон issue/PR + автопубликация через `publish-report.py`
     с `host_id`, `run_id`, фазой, списком артефактов.
5) BKL-005 — Усиленная редактирование секретов в логах/отчётах — DONE
   - Критерии: `export-report.py` удаляет/маскирует ключи/токены из env и логов,
     в отчёте нет явных секретов при тесте с фикстурами.

## P1 / Следующая итерация
6) BKL-006 — Валидации конфигурации оркестратора — DONE
   - Критерии: понятные ошибки при конфликте worktree, пустых полях, missing prompt.
7) BKL-007 — Обновлённый `.env` шаблон и `inputs-required-ru.md` — DONE
   - Критерии: список секретов для Supabase/Stripe/SES/Vercel|Netlify,
     ясные шаги запроса на креды.
8) BKL-008 — Тесты оркестратора (unit/integration) — DONE
   - Критерии: минимум 5 unit тестов на конфиг/lock/redact + 1 интеграционный no‑op.
9) BKL-011 — Исключить служебные папки из legacy‑аудита
   - Критерии: `framework/`, `framework.backup.*`, `_worktrees/` и `.git` не читаются при legacy‑audit.

## P2 / Optional
10) BKL-009 — Улучшение UX артефактов (master‑doc + оглавление + ссылки) — DONE
   - Критерии: единый обзорный документ с оглавлением и ссылками на детали.
11) BKL-010 — Интеграции аналитики/наблюдаемости (опционально)
    - Критерии: опциональные модули, не блокируют MVP.
